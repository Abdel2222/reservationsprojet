INSERT INTO `reservations` (`id`, `user_id`, `representation_id`, `places`) VALUES
(NULL, 2, 1, 3),
(NULL, 2, 2, 5);