INSERT INTO `user_role` (`id`, `user_id`, `role_id`) VALUES
(NULL, 1, 1),
(NULL, 2, 2),
(NULL, 3, 3);