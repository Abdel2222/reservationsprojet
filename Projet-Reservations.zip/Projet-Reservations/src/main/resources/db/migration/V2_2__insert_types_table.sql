INSERT INTO `types` (`id`, `type`) VALUES
(1, 'comédien'),
(2, 'scénographe'),
(3, 'auteur');