INSERT INTO tags (tag) VALUES ('Comedy');
INSERT INTO tags (tag) VALUES ('Drama');
INSERT INTO tags (tag) VALUES ('Musical');
