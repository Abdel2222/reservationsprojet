INSERT INTO prices (type, price, show_id) VALUES
('promo', 20.00, 1),
('senior', 15.00, 2),
('kids', 10.00, 1),
('promo', 25.00, 3);