INSERT INTO show_tag (show_id, tag_id) VALUES (1, 1);
INSERT INTO show_tag (show_id, tag_id) VALUES (2, 2);
INSERT INTO show_tag (show_id, tag_id) VALUES (3, 3);
INSERT INTO show_tag (show_id, tag_id) VALUES (1, 2);