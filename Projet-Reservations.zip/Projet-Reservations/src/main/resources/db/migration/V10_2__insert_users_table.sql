INSERT INTO `users` (`id`, `login`, `password`, `firstname`, `lastname`, `email`, `langue`,`role`, `created_at`) VALUES
(1, 'bob', '$2a$12$EyDxX5wWsrJGIyo2MFIRR.LqLmmqssUdPgwasMrG7TvZmjW9ECeLW', 'Bob', 'Sull', 'bob@sull.com','fr','admin','2010-01-01 12:00:00'),
(2, 'lana', '$2a$12$EyDxX5wWsrJGIyo2MFIRR.LqLmmqssUdPgwasMrG7TvZmjW9ECeLW', 'Lana', 'Sull', 'lana@sull.com','fr','member','2010-01-01 12:00:00'),
(3, 'affiliate', '$2a$12$EyDxX5wWsrJGIyo2MFIRR.LqLmmqssUdPgwasMrG7TvZmjW9ECeLW', 'Affi', 'Liate', 'contact@affiliate.com','fr','member','2020-01-01 12:00:00');