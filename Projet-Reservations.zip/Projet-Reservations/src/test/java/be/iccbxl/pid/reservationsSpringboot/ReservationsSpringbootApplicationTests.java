package be.iccbxl.pid.reservationsSpringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservationsSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
